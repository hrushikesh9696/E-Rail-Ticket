package com.railway.util;

public class AppConstant {
	public static final String ROLE="ROLE_USER";
	public static final String AUTH_HEADER = "authorization";
	public static final String AUTH_TOKEN_TYPE = "Bearer";
	public static final String AUTH_TOKEN_PREFIX = AUTH_TOKEN_TYPE + " ";
}
