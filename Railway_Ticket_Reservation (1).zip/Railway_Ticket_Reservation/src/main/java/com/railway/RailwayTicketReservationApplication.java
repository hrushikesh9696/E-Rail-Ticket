package com.railway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayTicketReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwayTicketReservationApplication.class, args);
	}

}
